﻿namespace Project
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.questionLabel = new System.Windows.Forms.Label();
            this.answerLabel = new System.Windows.Forms.Label();
            this.showAnswerButton = new System.Windows.Forms.Button();
            this.personNameLabel = new System.Windows.Forms.Label();
            this.textBoxInput = new System.Windows.Forms.TextBox();
            this.OutputNamelabel = new System.Windows.Forms.Label();
            this.showAnswerbutton2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // questionLabel
            // 
            this.questionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.questionLabel.Location = new System.Drawing.Point(291, 66);
            this.questionLabel.Name = "questionLabel";
            this.questionLabel.Size = new System.Drawing.Size(214, 25);
            this.questionLabel.TabIndex = 0;
            this.questionLabel.Text = "What university am I attending?";
            this.questionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // answerLabel
            // 
            this.answerLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.answerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.answerLabel.Location = new System.Drawing.Point(272, 111);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(249, 23);
            this.answerLabel.TabIndex = 1;
            this.answerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // showAnswerButton
            // 
            this.showAnswerButton.Location = new System.Drawing.Point(335, 156);
            this.showAnswerButton.Name = "showAnswerButton";
            this.showAnswerButton.Size = new System.Drawing.Size(110, 23);
            this.showAnswerButton.TabIndex = 2;
            this.showAnswerButton.Text = "show the Answer";
            this.showAnswerButton.UseVisualStyleBackColor = true;
            this.showAnswerButton.Click += new System.EventHandler(this.showAnswerButton_Click);
            // 
            // personNameLabel
            // 
            this.personNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.personNameLabel.Location = new System.Drawing.Point(272, 210);
            this.personNameLabel.Name = "personNameLabel";
            this.personNameLabel.Size = new System.Drawing.Size(214, 25);
            this.personNameLabel.TabIndex = 3;
            this.personNameLabel.Text = "What is your Name?";
            this.personNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBoxInput
            // 
            this.textBoxInput.Location = new System.Drawing.Point(272, 255);
            this.textBoxInput.Name = "textBoxInput";
            this.textBoxInput.Size = new System.Drawing.Size(249, 23);
            this.textBoxInput.TabIndex = 4;
            // 
            // OutputNamelabel
            // 
            this.OutputNamelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OutputNamelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OutputNamelabel.Location = new System.Drawing.Point(272, 315);
            this.OutputNamelabel.Name = "OutputNamelabel";
            this.OutputNamelabel.Size = new System.Drawing.Size(249, 23);
            this.OutputNamelabel.TabIndex = 5;
            this.OutputNamelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // showAnswerbutton2
            // 
            this.showAnswerbutton2.Location = new System.Drawing.Point(335, 358);
            this.showAnswerbutton2.Name = "showAnswerbutton2";
            this.showAnswerbutton2.Size = new System.Drawing.Size(110, 23);
            this.showAnswerbutton2.TabIndex = 6;
            this.showAnswerbutton2.Text = "show the Answer";
            this.showAnswerbutton2.UseVisualStyleBackColor = true;
            this.showAnswerbutton2.Click += new System.EventHandler(this.showAnswerbutton2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.showAnswerbutton2);
            this.Controls.Add(this.OutputNamelabel);
            this.Controls.Add(this.textBoxInput);
            this.Controls.Add(this.personNameLabel);
            this.Controls.Add(this.showAnswerButton);
            this.Controls.Add(this.answerLabel);
            this.Controls.Add(this.questionLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label questionLabel;
        private Label answerLabel;
        private Button showAnswerButton;
        private Label personNameLabel;
        private TextBox textBoxInput;
        private Label OutputNamelabel;
        private Button showAnswerbutton2;
    }
}