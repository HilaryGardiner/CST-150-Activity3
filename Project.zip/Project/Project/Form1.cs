namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showAnswerButton_Click(object sender, EventArgs e)
        {
            answerLabel.Text = "Grand Canyon University!";

        }

        private void showAnswerbutton2_Click(object sender, EventArgs e)
        {
            string name = textBoxInput.Text;
            OutputNamelabel.Text = name;
        }
    }
}